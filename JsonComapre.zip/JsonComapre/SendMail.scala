package spark.json.version3

import java.util._
import javax.mail._
import javax.mail.internet._
import javax.activation.FileDataSource
import javax.activation.DataHandler

class SendMail() {

  def sendEMail(filePath: String) {

    val from = "karna.trainer"  //Only the part before @gmail.com
    val pass = "Karna.3009"
    val to = "karna3009@gmail.com" // Recipient email addresses
    val subject = "Json data Processing Report"
    
    val props = System.getProperties()
    val host = "smtp.gmail.com"
    props.put("mail.smtp.starttls.enable", "true")
    props.put("mail.smtp.host", host)
    props.put("mail.smtp.user", from)
    props.put("mail.smtp.password", pass)
    props.put("mail.smtp.port", "587")
    props.put("mail.smtp.auth", "true")

    val session = Session.getDefaultInstance(props)
    val message = new MimeMessage(session)

    try {
      message.setFrom(new InternetAddress(from))
      val toAddress = new InternetAddress(to)

      val multipart = new MimeMultipart()
      val messageBodyPart = new MimeBodyPart()
      val filename = filePath
      val source = new FileDataSource(filename)
      
      messageBodyPart.setDataHandler(new DataHandler(source))
      messageBodyPart.setFileName(filename)
      multipart.addBodyPart(messageBodyPart)
      message.addRecipient(Message.RecipientType.TO, toAddress)
      message.setSubject(subject)
      message.setContent(multipart)
      
      val transport = session.getTransport("smtp")
      transport.connect(host, from, pass)
      transport.sendMessage(message, message.getAllRecipients())
      transport.close()
      
      println("Email Sent Successfully")

    } catch {

      case ae: AddressException => ae.printStackTrace();

      case me: MessagingException => me.printStackTrace();
    }
  }
}