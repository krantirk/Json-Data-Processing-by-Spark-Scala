package spark.json.version3

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import java.io.IOException

object JsonCompare {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder.
      master("local[2]").
      appName("sqlApp").
      config("spark.executor.memory", "8G").
      config("spark.serializer", "org.apache.spark.serializer.KryoSerializer").
      enableHiveSupport.
      getOrCreate
    spark.sparkContext.setLogLevel("INFO")
    import spark.implicits._

    /* The arguements refer to as follows
     args(0) --> directory of preshift files
     args(1) --> directory of postshift files
     args(2) --> output table name to which data has to be wriiten to
     args(3) --> A unique id for the application
     args(4) --> Path where output file has to be created
     */

    val preshiftdir = args(0)
    val postshiftdir = args(1)
    val OutputTable = args(2)
    val UniqueId = args(3).toInt
    val OutputFilePath = args(4)

    //Reading the files from the directories
    val ob1 = new ValidateJson(OutputTable)

    val preShiftDir = ob1.getListOfFiles(preshiftdir)
    val preShiftFiles = preShiftDir.map(x => x.toString)

    val postShiftDir = ob1.getListOfFiles(postshiftdir)
    val postShiftFiles = postShiftDir.map(x => x.toString)

    //Performing the comparison of files
    val no_of_files = preShiftFiles.size
    var file_no = 1
    for (fno <- 1 to no_of_files) {
      val file_name = preShiftFiles(file_no - 1)
      val file_names = file_name.split("_")
      val file_name_metric = file_names(1)
      val file_name_category = file_names(2)
      val file_name_viewBy = file_names(3)

      val preShiftFile = preShiftFiles(fno - 1)
      val postShiftFile = postShiftFiles(fno - 1)

      val rd1 = spark.sparkContext.wholeTextFiles(preShiftFile)
      val rd2 = rd1.map(x => x._2).map(x => x.replace("\n", ""))
      val preJsonDF = spark.read.json(rd2)

      val rd3 = spark.sparkContext.wholeTextFiles(postShiftFile)
      val rd4 = rd3.map(x => x._2).map(x => x.replace("\n", ""))
      val postJsonDF = spark.read.json(rd4)

      //Verifying whether the schema of 2 dataframes is same or not
      if (preJsonDF.schema == postJsonDF.schema) {
        val columns = preJsonDF.columns
        ob1.validate(preJsonDF, postJsonDF, columns, file_no, file_name_metric, file_name_category, file_name_viewBy)
      } //end of 'if' statement
      else {
        val columns = (preJsonDF.columns).intersect(postJsonDF.columns)
        ob1.validate(preJsonDF, postJsonDF, columns, file_no, file_name_metric, file_name_category, file_name_viewBy)
      } //end of 'else' statement
      file_no = file_no + 1

    }
    //end of the loop

    val df1 = spark.read.table(OutputTable).where("Status='false'")

    if (df1.count == 0) {
      println("All Files are Passed")
    } else {
      val df2 = df1.select("FileNo", "Key", "Metric", "Category", "ViewBy", "OriginalValue", "ChangedValue", "Status").withColumn("UniqueID", lit(UniqueId))
      val d1 = df2.select(col("UniqueID"), col("FileNo"), col("Key"), col("Metric"), col("Category"), col("ViewBy"), col("Status"), explode(col("OriginalValue")))
      val d2 = df2.select(col("UniqueID"), col("FileNo"), col("Key"), col("Metric"), col("Category"), col("ViewBy"), col("Status"), explode(col("ChangedValue")))
      val r1 = d1.rdd
      val r2 = d2.rdd
      val r3 = r1.zip(r2).map(x => (x._1.get(0).toString.toInt, x._1.get(1).toString.toInt, x._1.get(2).toString, x._1.get(3).toString, x._1.get(4).toString, x._1.get(5).toString, x._1.get(6).toString, x._1.get(7).toString, x._2.get(7).toString))

      val df = r3.toDF("UniqueID", "FileNo", "Key", "Metric", "Category", "ViewBy", "Status", "OriginalValue", "ChangedValue").
        withColumn("TimeStamp", current_timestamp)
      val dfFinal = df.select("UniqueID", "FileNo", "Metric", "Category", "ViewBy", "Key", "OriginalValue", "ChangedValue", "TimeStamp", "Status")

      try {
        //Saving the output as a file to a path
        dfFinal.coalesce(1).write.format("csv").mode("overwrite").option("header", "true").
          save("C:\\Users\\KARUNAKAR\\Desktop\\joutput")

        //Code to relocate the output file to the desired location
        import org.apache.hadoop.fs._
        val sc = spark.sparkContext
        val fs = FileSystem.get(sc.hadoopConfiguration)
        val file = fs.globStatus(new Path("C:\\Users\\KARUNAKAR\\Desktop\\joutput\\part*.csv"))(0).getPath.getName

        fs.rename(new Path("C:\\Users\\KARUNAKAR\\Desktop\\joutput\\" + file), new Path(OutputFilePath))
      } catch {
        case ex: IOException =>
          spark.sql("DROP TABLE IF EXISTS KRANTHI")
          println("Unable to create the file ..Check whether file is open?")
      }

      try {
        //Saving the output to a table in MySQL Database
        val driver = "com.mysql.jdbc.Driver"
        val url = "jdbc:mysql://172.16.38.131:3306"
        val user = "KARUNAKAR"
        val dbtable = "kranthi.json5"
        val password = "karna"
        dfFinal.write.format("jdbc").options(Map("spark.driver" -> driver, "url" -> url, "user" -> user, "password" -> password, "dbtable" -> dbtable)).mode("append").save()
      } catch {
        case ex: com.mysql.jdbc.exceptions.jdbc4.CommunicationsException =>
          spark.sql("DROP TABLE IF EXISTS KRANTHI")
          println("Unable to Establish connection to Mysql..please check the network connections")

        case ex: java.net.ConnectException =>
          spark.sql("DROP TABLE IF EXISTS KRANTHI")
          println("Unable to connect to Mysql Server..please check the network connections")
       
        case ex: java.sql.SQLException =>
          spark.sql("DROP TABLE IF EXISTS KRANTHI")
          println("Unable to connect to Mysql Server..please Check the User Previliges to write to MySQL")
      }
      
      
         dfFinal.filter("Status='false'").show
       
    spark.sql("DROP TABLE IF EXISTS KRANTHI") //Dropping the table after data is retreived into desired location
    }
    val mailOb = new SendMail()
    mailOb.sendEMail(OutputFilePath)

    spark.stop()
  }
  //end of the main method
}
//end of the class