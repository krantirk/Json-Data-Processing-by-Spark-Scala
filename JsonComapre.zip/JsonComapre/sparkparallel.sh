/usr/hdp/current/spark2-client/bin/spark-submit --name email_channel_ads \
--driver-java-options -Djava.io.tmpdir=/hadoop/tmp --conf spark.local.dir=/hadoop/tmp \
--conf "spark.executor.extraJavaOptions=-Dhdp.version=2.6.0.3-8" --conf "spark.driver.extraJavaOptions=-Djava.io.tmpdir=/hadoop/tmp" \
--conf "spark.yarn.am.extraJavaOptions=-Dhdp.version=2.6.0.3-8" \
--conf "spark.sql.parquet.writeLegacyFormat=true" \
--master yarn \
--deploy-mode=cluster --driver-memory 7G --executor-memory 7G --executor-cores 12 --num-executors 6 \
--keytab  /home/hfeaengd/hfeaengd.keytab \
--principal hfeaengd@ACCOUNTS.ROOT.CORP \
--files /usr/hdp/current/spark2-client/conf/hive-site.xml \
--jars FinalUDF-1.0-SNAPSHOT.jar \
--class com.esi.Analyz.AnalyticalDataSetRun HC360_FENG-1.0.0-WITH_PARTITIONS.jar  $0 $1 $2 $3
~
if [ $3  == HC360_FENG-1.0.0-WITH_PARTITIONS.jar ] || [ $3  == HC360_FENG-1.0.0-WITH_PARTITIONS.jar ] 
then
    $3
else
    $3 /home/hfeaengd/Kranti

