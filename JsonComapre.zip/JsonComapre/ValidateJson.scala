package spark.json.version3

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit
import java.io.File
import org.apache.spark.sql.functions._

class ValidateJson(OutputTable: String) {
  val spark = SparkSession.builder.getOrCreate
  import spark.implicits._

  //Function to get the list of files from the given directory
  def getListOfFiles(dir: String): List[File] = {
    val d = new File(dir)
    if (d.exists && d.isDirectory) {
      d.listFiles.filter(_.isFile).toList
    } else {
      List[File]()
    }
  }

  //Function to evaluate if schema is available
  def validate(preJsonDF: org.apache.spark.sql.DataFrame, postJsonDF: org.apache.spark.sql.DataFrame, columns: Array[String], file_no: Int, file_name_metric: String, file_name_category: String, file_name_viewBy: String) {
    for (i <- 0 to columns.size - 1) {
      val c = columns(i)
      val rd1 = preJsonDF.select(c).rdd.repartition(3)
      val rd2 = postJsonDF.select(c).rdd.repartition(3)
      val rd3 = rd1.zip(rd2)

      val rd4 = rd3.map { x =>
        val x1 = x._1.toString
        val x2 = x._2.toString
        val comp = x1.equals(x2)
        val diff: (List[String], List[String]) = if (comp == false) {
          var OriginalValues = List("")
          var ChangedValues = List("")
          var OriginalValue = ""
          var ChangedValue = ""
          val diff1 = x1.split(",")
          val diff2 = x2.split(",")
          val difference = diff1.zip(diff2).filter(x => x._1 != x._2).toList
          for (j <- 0 to difference.size - 1) {
            OriginalValue = difference(j)._1.replace("[", "").replace("]", "")
            ChangedValue = difference(j)._2.replace("[", "").replace("]", "")
            OriginalValues = OriginalValue :: OriginalValues
            ChangedValues = ChangedValue :: ChangedValues
          }
          val OV = OriginalValues.filter(_ != "")
          val CV = ChangedValues.filter(_ != "")
          (OV, CV)
        } else (List(""), List(""))
        (c, comp.toString(), diff._1, diff._2)
      } // end of rdd transformation

      val df1 = rd4.toDF("Key", "Status", "OriginalValue", "ChangedValue")
      val df2 = df1.select("*").
        withColumn("FileNo", lit(file_no)).
        withColumn("Metric", lit(file_name_metric)).
        withColumn("Category", lit(file_name_category)).
        withColumn("ViewBy", lit(file_name_viewBy))
      df2.write.mode("append").saveAsTable(OutputTable)
    } //end of the loop

  } //end of the function "validate"

} //end of class "ValidateJson"